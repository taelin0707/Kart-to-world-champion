import {trackLayouts} from './track-layouts.js';
export const stats=['레이스 페이스','예선 능력','추월','레이스 운영','타이어 관리','멘탈','체력'];
export const categories=['KART','F4','F3','F2','F1'];
export const countries={kr:{name:'대한민국',cost:25,growth:1,wet:.2,desc:'저렴한 운영비 · 해외 스카우트 노출 −4%'},jp:{name:'일본',cost:40,growth:1.07,wet:.3,desc:'운영·멘탈 훈련 +7% · 운영비 증가'},uk:{name:'영국',cost:65,growth:1.05,wet:.45,desc:'스카우트 노출 +4% · 높은 운영비'},it:{name:'이탈리아',cost:50,growth:1.08,wet:.2,desc:'페이스·예선 훈련 +8% · 운영비 증가'}};
export const circuits=[
{id:'monza',name:'몬차',base:81,weights:[.4,.2,.25,.05,.03,.02,.05],car:[.6,.1,.2,.05,.05],wear:.75},
{id:'monaco',name:'모나코',base:76,weights:[.15,.25,.08,.3,.07,.1,.05],car:[.05,.6,.2,.1,.05],wear:.7},
{id:'suzuka',name:'스즈카',base:91,weights:[.25,.1,.1,.2,.15,.1,.1],car:[.15,.5,.15,.15,.05],wear:1.2},
{id:'silverstone',name:'실버스톤',base:89,weights:[.3,.1,.1,.1,.15,.1,.15],car:[.25,.4,.1,.2,.05],wear:1.15},
{id:'yeongam',name:'영암',base:94,weights:[.2,.15,.2,.2,.1,.05,.1],car:[.3,.3,.2,.15,.05],wear:1},
{id:'spa',name:'스파',base:108,weights:[.3,.1,.15,.15,.1,.1,.1],car:[.4,.3,.15,.1,.05],wear:1.1}];
for(const circuit of circuits)Object.assign(circuit,trackLayouts[circuit.id]);
const templates=[['Apex','Crimson','#d63b51',1.18,-4,70,45],['Vertex','Cobalt','#3478e6',.88,4,82,65],['Nova','Violet','#9a65de',1,0,60,38],['Orion','Jade','#26b29b',1.05,2,90,75]];
export function teamData(){return categories.flatMap((cat,c)=>templates.map((t,i)=>({id:`${c}-${i}`,name:`${t[0]} ${cat==='KART'?'Karting':cat}`,cat:c,color:t[2],growth:t[3],development:t[5],finance:t[6],criteria:35+c*10+i*1.5,salary:30*(c+1)**2+i*12,car:Array.from({length:5},(_,k)=>Math.min(97,40+c*10+t[4]+[2,-1,0,1,6][k])),expect:i===1?3:6})));}
export const npcNames=['루카 로시','노아 베르거','유토 타나카','올리버 리드','레오 마르탱','에밀 뮐러','가브리엘 실바','리암 워커','카이 윌슨','마테오 코스타','휴고 뒤부아','소피아 로페즈','로건 클라크','이준서','루이스 산토스','엔조 루소'];
