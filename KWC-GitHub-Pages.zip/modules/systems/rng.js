export const clamp=(x,a=0,b=100)=>Math.max(a,Math.min(b,x));
export function rng(s){s.seed=(Math.imul(s.seed,1664525)+1013904223)>>>0;return s.seed/4294967296}
export const range=(s,a,b)=>a+rng(s)*(b-a);
export const pick=(s,a)=>a[Math.floor(rng(s)*a.length)];
export const avg=a=>a.reduce((x,y)=>x+y,0)/a.length;
